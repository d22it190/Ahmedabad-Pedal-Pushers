<!DOCTYPE html>

<html class="no-js" lang="en-US">

  <head>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
            
      <title>Contact Us </title>
            
<link rel='stylesheet' id='turbo-style-css'  href='https://www.citycycling.in/wp-content/themes/turbo/assets/dist/css/turbo.style.css?ver=5.4.9' type='text/css' media='all' />
<link rel='stylesheet' id='js_composer_front-css'  href='https://www.citycycling.in/wp-content/plugins/js_composer/assets/css/js_composer.min.css?ver=5.0.1' type='text/css' media='all' />
    <style type="text/css" title="dynamic-css" class="options-output">body{opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading body,{opacity: 0;}.ie.wf-loading body,{visibility: hidden;}
                                    .navbar .container .navbar-nav li a,
                                    .navbar .container-fluid .navbar-nav li a
                                {font-family:Montserrat;line-height:20px;font-weight:normal;font-style:400;color:#f5f5f5;font-size:12px;opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading 
                                    .navbar .container .navbar-nav li a,
                                    .navbar .container-fluid .navbar-nav li a
                                ,{opacity: 0;}.ie.wf-loading 
                                    .navbar .container .navbar-nav li a,
                                    .navbar .container-fluid .navbar-nav li a
                                ,{visibility: hidden;}
                                    .navbar .container .navbar-nav li .dropdown-menu li a,
                                    .navbar .container .navbar-nav .dropdown-menu li a,
                                    .navbar .container-fluid .navbar-nav .dropdown-menu li a,
                                    .headroom-sticky.sticky-scroll .navbar.navbar-default .navbar-nav li .dropdown-menu a
                                {font-family:Montserrat;line-height:20px;font-weight:normal;font-style:400;color:#f5f5f5;font-size:12px;opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading 
                                    .navbar .container .navbar-nav li .dropdown-menu li a,
                                    .navbar .container .navbar-nav .dropdown-menu li a,
                                    .navbar .container-fluid .navbar-nav .dropdown-menu li a,
                                    .headroom-sticky.sticky-scroll .navbar.navbar-default .navbar-nav li .dropdown-menu a
                                ,{opacity: 0;}.ie.wf-loading 
                                    .navbar .container .navbar-nav li .dropdown-menu li a,
                                    .navbar .container .navbar-nav .dropdown-menu li a,
                                    .navbar .container-fluid .navbar-nav .dropdown-menu li a,
                                    .headroom-sticky.sticky-scroll .navbar.navbar-default .navbar-nav li .dropdown-menu a
                                ,{visibility: hidden;}h2.rq-title{font-family:Oswald;line-height:44px;font-weight:normal;font-style:400;color:#000000;font-size:24px;opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading h2.rq-title,{opacity: 0;}.ie.wf-loading h2.rq-title,{visibility: hidden;}.rq-blog-list-thumb-single .rq-listing-title a{font-family:Montserrat;line-height:16px;font-weight:normal;font-style:400;color:#000;font-size:16px;opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading .rq-blog-list-thumb-single .rq-listing-title a,{opacity: 0;}.ie.wf-loading .rq-blog-list-thumb-single .rq-listing-title a,{visibility: hidden;}.rq-blog-list-thumb-single .post-content p{font-family:"Open Sans";line-height:24px;font-weight:normal;font-style:400;color:#666;font-size:13px;opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading .rq-blog-list-thumb-single .post-content p,{opacity: 0;}.ie.wf-loading .rq-blog-list-thumb-single .post-content p,{visibility: hidden;}.rq-sidebar h4.widget-title{font-family:Montserrat;line-height:44px;font-weight:normal;font-style:400;color:#000;font-size:18px;opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading .rq-sidebar h4.widget-title,{opacity: 0;}.ie.wf-loading .rq-sidebar h4.widget-title,{visibility: hidden;}.rq-sidebar ul li a{font-family:"Open Sans";line-height:24px;font-weight:normal;font-style:400;color:#666;font-size:14px;opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading .rq-sidebar ul li a,{opacity: 0;}.ie.wf-loading .rq-sidebar ul li a,{visibility: hidden;}.rq-main-footer h4.widget-title{font-family:Montserrat-Regular;line-height:44px;font-weight:normal;font-style:400;color:#fff;font-size:18px;opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading .rq-main-footer h4.widget-title,{opacity: 0;}.ie.wf-loading .rq-main-footer h4.widget-title,{visibility: hidden;}.rq-main-footer ul li a{font-family:"Open Sans";line-height:24px;font-weight:normal;font-style:400;color:#999;font-size:13px;opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading .rq-main-footer ul li a,{opacity: 0;}.ie.wf-loading .rq-main-footer ul li a,{visibility: hidden;}.copyright-content p{font-family:Montserrat-Regular;line-height:24px;font-weight:normal;font-style:400;color:#666;font-size:14px;opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading .copyright-content p,{opacity: 0;}.ie.wf-loading .copyright-content p,{visibility: hidden;}</style><noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>    
 
    
  </head>

  <body data-rsssl=1 class="page-template-default page page-id-167 theme-turbo woocommerce-no-js wpb-js-composer js-comp-ver-5.0.1 vc_responsive">  
    
    <div id="main-wrapper">
<nav class="navbar navbar-default" id="sticker" style="background-image: url() ; background-color: #000; background-repeat: repeat-x; -webkit-background-size: cover; background-size: cover; background-position: center center; background-attachment: scroll;">
<div class="col-md-12 col-sm-12 widget-list top-container"><div class="container t-center"><div class="menu-header_top_menu-container">
  <ul id="menu-header_top_menu" class="menu">
<li id="menu-item-911" ><a href="http://localhost/nivea/app.php" >Home Page</a></li>
            <li id="menu-item-911" ><a href="http://localhost/nivea/dboard.php" > Dashboard </a></li>
<li id="menu-item-1390" ><a href="http://localhost/nivea/aboutus.php" >About Us</a>
</li>
</ul>            
        </div>
      </div>
</nav>

       <div class="rq-content-block">
                    <div class="container">

   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

  <h3 class="head_title">Contact Us</h3>
  

        
<div class="col-md-4">
    <div class="grid-block-single">
        <h3>Phone</h3>
        <p>123456789</p>
        <p> (1233456677)</p>
    </div>
</div>

<div class="col-md-4">
    <div class="grid-block-single">
        <h3>Email</h3>
        <p>ahmedabadpedalpushers@gmail.com</p>
        <p> </p>
    </div>
</div>
    
<div class="vc_row wpb_row vc_row-fluid"><div class="contact-heading wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
  <div class="wpb_text_column wpb_content_element  ram-text">
    <div class="wpb_wrapper">
      <hr>
      <h3>If you got any questions please send us a message</h3>

    </div>
  </div>
</div></div></div>

<div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper"><div role="form" class="wpcf7" id="wpcf7-f695-p167-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response" role="alert" aria-live="polite"></div>

<form action="dbcontactus.php" method="post" class="wpcf7-form init" enctype="multipart/form-data" ">

<div class="rq-contact-us-form-content">
 <hr> 
<p>
<label class="label_text">Email address <span class="wppb-required" title="This field is required">*</span></label><br />
<span class="wpcf7-form-control-wrap email-295"><input type="email" name="email" id="email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email contact-form-input" aria-required="true" aria-invalid="false" placeholder="Your Email" required /></span><br />

<label class="label_text">Subject Heading</label><br />
<span class="wpcf7-form-control-wrap email-295"><input type="text" name="subh" id="subh" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email contact-form-input"class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email contact-form-input" aria-required="true" aria-invalid="false" placeholder="Subject Heading" required /></span><br />
<label class="label_text">Message</label><br />
<span class="wpcf7-form-control-wrap textarea-652"><textarea name="textarea" id="textarea" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea wpcf7-validates-as-required contact-form-input" aria-required="true" aria-invalid="false" required ></textarea></span></p>

<center><input type="submit" name="submit" id="submit" value="Submit Message"></center>
</div>

<div class="wpcf7-response-output" role="alert" aria-hidden="true"></div></form></div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="wpb_gmaps_widget wpb_content_element">
    <div class="wpb_wrapper">
    <div class="wpb_map_wraper">
      <iframe src="http://blog.fantabeans.com/wp-content/uploads/2016/11/cycling-800x535.jpg" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>   </div>
  </div>
</div>
</div></div></div></div>
        <div class="link-pages">
                    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
</div> 

    <footer class="rq-footer site-footer">

<div class="rq-main-footer" style="background-image: url() ; background-color: #212020; background-repeat: repeat-x; -webkit-background-size: cover; background-size: cover; background-position: center center; background-attachment: scroll;">
    <div class="container-fluid">
    <button class="toggle-widget"></button>
        <div class="row">
            <div class="footer-logo col-md-3">
            <div class="col-md-3 col-sm-3 widget-list">     <div class="textwidget"><p></p>
</div>
    </div>            </div>
            <div class="footer-tree-list col-md-6">
            <ul class="widg">
              <li id="nav_menu-5" class="widget widget_nav_menu"><h2 class="widgettitle">Categories</h2>
<div class="menu-footer2_menu-container">
<ul id="menu-footer2_menu" class="menu">
<li id="menu-item-1452" ><a href="http://localhost/nivea/basiccycle.php">Basic Cycles</li>
<li id="menu-item-1453" ><a href="http://localhost/nivea/gearcycle.php">Gear Cycles</li>
<li id="menu-item-1454" ><a href="http://localhost/nivea/toddlercycle.php">Toddlers Cycles</li>
</ul></div></li>
<li id="nav_menu-2" class="widget widget_nav_menu"><h2 class="widgettitle">Information</h2>
<div class="menu-footer_menu-container">
  <ul id="menu-footer_menu" class="menu">
<li id="menu-item-1307" ><a href="http://localhost/nivea/contactus.php" aria-current="page">Contact Us</a></li>
<li id="menu-item-1252" ><a href="http://localhost/nivea/t&c.php">Terms &#038; Conditions</a></li>
</ul></div></li>
<li id="nav_menu-3" class="widget widget_nav_menu"><h2 class="widgettitle"> Account</h2>
<div class="menu-turbo-left-menu-container"><ul id="menu-turbo-left-menu" class="menu">
  
<li id="menu-item-1826" ><a href="http://localhost/nivea/myacc.php">My Account</a></li>
</ul></div></li>
  
              </ul>
            </div>
            
        </div>
    </div>
</div>

    </footer>
 
  <link rel="stylesheet" type="text/css" href="https://www.citycycling.in/wp-content/themes/turbo-child/css/custom-style.css">

  </body>
</html>

