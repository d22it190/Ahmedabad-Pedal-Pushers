<!DOCTYPE html>

<html class="no-js" lang="en-US">

<!--<![endif]-->
  <head>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
      <title>Edit | My Account</title>
    <link rel='stylesheet' id='turbo-style-css'  href='https://www.citycycling.in/wp-content/themes/turbo/assets/dist/css/turbo.style.css?ver=5.4.9' type='text/css' media='all' />
<link rel='stylesheet' id='wppb_stylesheet-css'  href='https://www.citycycling.in/wp-content/plugins/profile-builder/assets/css/style-front-end.css?ver=3.1.9' type='text/css' media='all' />
    <style type="text/css" title="dynamic-css" class="options-output">body{opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading body,{opacity: 0;}.ie.wf-loading body,{visibility: hidden;}
                                    .navbar .container .navbar-nav li a,
                                    .navbar .container-fluid .navbar-nav li a
                                {font-family:Montserrat;line-height:20px;font-weight:normal;font-style:400;color:#f5f5f5;font-size:12px;opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading 
                                    .navbar .container .navbar-nav li a,
                                    .navbar .container-fluid .navbar-nav li a
                                ,{opacity: 0;}.ie.wf-loading 
                                    .navbar .container .navbar-nav li a,
                                    .navbar .container-fluid .navbar-nav li a
                                ,{visibility: hidden;}
                                    .navbar .container .navbar-nav li .dropdown-menu li a,
                                    .navbar .container .navbar-nav .dropdown-menu li a,
                                    .navbar .container-fluid .navbar-nav .dropdown-menu li a,
                                    .headroom-sticky.sticky-scroll .navbar.navbar-default .navbar-nav li .dropdown-menu a
                                {font-family:Montserrat;line-height:20px;font-weight:normal;font-style:400;color:#f5f5f5;font-size:12px;opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading 
                                    .navbar .container .navbar-nav li .dropdown-menu li a,
                                    .navbar .container .navbar-nav .dropdown-menu li a,
                                    .navbar .container-fluid .navbar-nav .dropdown-menu li a,
                                    .headroom-sticky.sticky-scroll .navbar.navbar-default .navbar-nav li .dropdown-menu a
                                ,{opacity: 0;}.ie.wf-loading 
                                    .navbar .container .navbar-nav li .dropdown-menu li a,
                                    .navbar .container .navbar-nav .dropdown-menu li a,
                                    .navbar .container-fluid .navbar-nav .dropdown-menu li a,
                                    .headroom-sticky.sticky-scroll .navbar.navbar-default .navbar-nav li .dropdown-menu a
                                ,{visibility: hidden;}h2.rq-title{font-family:Oswald;line-height:44px;font-weight:normal;font-style:400;color:#000000;font-size:24px;opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading h2.rq-title,{opacity: 0;}.ie.wf-loading h2.rq-title,{visibility: hidden;}.rq-blog-list-thumb-single .rq-listing-title a{font-family:Montserrat;line-height:16px;font-weight:normal;font-style:400;color:#000;font-size:16px;opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading .rq-blog-list-thumb-single .rq-listing-title a,{opacity: 0;}.ie.wf-loading .rq-blog-list-thumb-single .rq-listing-title a,{visibility: hidden;}.rq-blog-list-thumb-single .post-content p{font-family:"Open Sans";line-height:24px;font-weight:normal;font-style:400;color:#666;font-size:13px;opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading .rq-blog-list-thumb-single .post-content p,{opacity: 0;}.ie.wf-loading .rq-blog-list-thumb-single .post-content p,{visibility: hidden;}.rq-sidebar h4.widget-title{font-family:Montserrat;line-height:44px;font-weight:normal;font-style:400;color:#000;font-size:18px;opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading .rq-sidebar h4.widget-title,{opacity: 0;}.ie.wf-loading .rq-sidebar h4.widget-title,{visibility: hidden;}.rq-sidebar ul li a{font-family:"Open Sans";line-height:24px;font-weight:normal;font-style:400;color:#666;font-size:14px;opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading .rq-sidebar ul li a,{opacity: 0;}.ie.wf-loading .rq-sidebar ul li a,{visibility: hidden;}.rq-main-footer h4.widget-title{font-family:Montserrat-Regular;line-height:44px;font-weight:normal;font-style:400;color:#fff;font-size:18px;opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading .rq-main-footer h4.widget-title,{opacity: 0;}.ie.wf-loading .rq-main-footer h4.widget-title,{visibility: hidden;}.rq-main-footer ul li a{font-family:"Open Sans";line-height:24px;font-weight:normal;font-style:400;color:#999;font-size:13px;opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading .rq-main-footer ul li a,{opacity: 0;}.ie.wf-loading .rq-main-footer ul li a,{visibility: hidden;}.copyright-content p{font-family:Montserrat-Regular;line-height:24px;font-weight:normal;font-style:400;color:#666;font-size:14px;opacity: 1;visibility: visible;-webkit-transition: opacity 0.24s ease-in-out;-moz-transition: opacity 0.24s ease-in-out;transition: opacity 0.24s ease-in-out;}.wf-loading .copyright-content p,{opacity: 0;}.ie.wf-loading .copyright-content p,{visibility: hidden;}</style><noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>    
    
  </head>

  <body data-rsssl=1 class="page-template-default page page-id-164 logged-in admin-bar no-customize-support theme-turbo woocommerce-account woocommerce-page woocommerce-edit-account woocommerce-no-js wpb-js-composer js-comp-ver-5.0.1 vc_responsive">  
    <div id="main-wrapper">

    <nav class="navbar navbar-default" id="sticker" style="background-image: url() ; background-color: #000; background-repeat: repeat-x; -webkit-background-size: cover; background-size: cover; background-position: center center; background-attachment: scroll;">
<div class="col-md-12 col-sm-12 widget-list top-container"><div class="container t-center"><div class="menu-header_top_menu-container">
  <ul id="menu-header_top_menu" class="menu">
    <li id="menu-item-1686" ><a href="http://localhost/nivea/myacc.php">My Account</a></li>
<li id="menu-item-1220" ><a href="http://localhost/nivea/app.php">Home Page</a></li>
<li id="menu-item-1220" ><a href="http://localhost/nivea/logout.php">LOGOUT</a></li>

</div></div></div>             
            
  
      </div>
</nav>

       <div class="rq-content-block">
                    <div class="container">

  <h3 class="head_title">Account details</h3>
  
<div class="rq-shopping-content-block">
    <div class="post-content">
        <div class="login-left"><div class="woocommerce">

<div class="col-md-3">
  
  <div class="user-account">
    <div class="user-account-portrait">
        <img src="https://previews.123rf.com/images/cteconsulting/cteconsulting1507/cteconsulting150700061/42815338-abstract-person-riding-a-bicycle-while-wearing-a-helmet-.jpg?fj=1" width="100" height="100" alt="Avatar" class="avatar avatar-100 wp-user-avatar wp-user-avatar-100 photo avatar-default" />           
      </div>      
  </div>

  <nav class="woocommerce-MyAccount-navigation">
    <ul class="nav nav-stacked rq-elements-menu">
        <li class="woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--orders">
          <a href="http://localhost/nivea/contactus.php">Contact Us</a>
        </li>
              <li class="woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--dashboard">
          <a href="http://localhost/nivea/t&c.php">Terms & Conditions</a>
        </li>
              
              <li class="woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--edit-account">
          <a href="http://localhost/nivea/edit.php">Account details</a>
        </li>
              
              
          </ul>
  </nav>
</div>

<div class="col-md-9">
  <div class="woocommerce-MyAccount-content">
    <div class="woocommerce-notices-wrapper"></div>
<div class="rq-registration-content-single small-bottom-margin"> <!-- start of registration portion -->
    <div class="rq-login-form no-border">

    <form class="woocommerce-EditAccountForm edit-account form-horizontal" action="dbedit.php" method="post">
      <div class="row">
        
        <div class="col-md-6">
          <input type="text" class="woocommerce-Input woocommerce-Input--text input-text rq-form-control reverse" name="account_first_name" id="account_first_name" placeholder="First Name" value="" required />
        </div>
        <div class="col-md-6">
          <input type="text" class="woocommerce-Input woocommerce-Input--text input-text  rq-form-control reverse" name="account_last_name" id="account_last_name" placeholder="Last Name" value="" required />
        </div>
        <div class="clear"></div>

        <div class="col-md-12">
          <input type="email" class="woocommerce-Input woocommerce-Input--email input-text  rq-form-control reverse" name="account_email" id="account_email" placeholder="Email address" value="" required 
required />
        </div>

        <div class="clear"></div>
        
        <div class="col-md-12">
          <h4 class="rq-change-password" style="padding-bottom: 25px;">Change password</h4>
        </div>
        

        <div class="col-md-12">
          <input type="password" class="woocommerce-Input woocommerce-Input--password input-text rq-form-control reverse" name="password_current" id="password_current" placeholder="Current Password " pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required 
required  />
        </div>

        <div class="clear"></div>

        <div class="col-md-6">
          <input type="password" class="woocommerce-Input woocommerce-Input--password input-text rq-form-control reverse" name="password_1" id="password_1"  placeholder="New Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required 
required />
        </div>            
        <div class="col-md-6">
          <input type="password" class="woocommerce-Input woocommerce-Input--password input-text rq-form-control reverse" name="password_2" id="password_2" placeholder="Confirm New Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required 
required  />
        </div>

        <div class="clear"></div>

        
  
        <div class="col-md-12">
                    <div class="register-button">
                      <input type="hidden" id="_wpnonce" name="_wpnonce" value="84195a0f62" /><input type="hidden" name="_wp_http_referer" value="/my-account/edit-account/" />                     
                        <input type="submit" class="rq-btn rq-btn-primary border-radius" name="save_account_details" value="Save changes" />
                        <input type="hidden" name="action" value="save_account_details" />
                    </div>
                </div>

              </div>
    </form>
  </div>
</div>

  </div>
</div>
</div>
</div>
    </div>
    </div>
    </div>
    </div>
    </div>
</div> 
<div class="new-blog-home">
<div class="container">
</div>
</div>
<div class="psfw-display-popup">
</div>
<div class="psfw-attributes-container">

</div>  
    
  <link rel="stylesheet" type="text/css" href="https://www.citycycling.in/wp-content/themes/turbo-child/css/custom-style.css">

  </body>
</html>

